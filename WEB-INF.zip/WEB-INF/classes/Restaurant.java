import java.io.*;
import java.util.*;
import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.WebServlet;

@WebServlet("/Restaurant")

public class Restaurant extends HttpServlet
{
	final static String SESSION_ADDTOCART = "add_to_cart";

	protected void doGet(HttpServletRequest request, HttpServletResponse response) 
		throws ServletException, IOException 
	{
		response.setContentType("text/html");
		PrintWriter pw = response.getWriter();
		Utilities utility = new Utilities(request, pw);
		utility.printHtml("Header.html");
		utility.printHtml("LeftNavigationBar.html");
		String contentData = "<div id='content'>";
		//HttpSession session;


		//SAXParser_DataStore productsDataStore = new SAXParser_DataStore();
		//List<Product> phones_list = productsDataStore.getPhoneList();
		List<Product> phones_list = ProductsHashMap.getPhoneList();

		//List<Product> phones_list = SAXParser_DataStore.phone_list;
		//String productCategory = request.getParmeter("maker");
		//if(productCategory == null)
		//{	}

		HttpSession session = request.getSession();
		
		Product product;
		if(phones_list == null)
		{
			contentData += "null data</div>";
		}
		else if(phones_list != null)
		{
			//contentData += "not null data....... yupieeeee..........<div>"+phones_list.size()+"</div>";
			contentData += "<div id='holder'>"
							+ "<h3 id='product_header'>Restaurants</h3>"
							+ "<div id='products_holder'>"
								+ "<div class='entry'>"
									+ "<table id='best_seller'>";

			for(int i=0; i<phones_list.size(); i++)
			{
				product = (Product)phones_list.get(i);
				session.setAttribute(SESSION_ADDTOCART, product);

				//Even numbered products(0,2,4,..)-> new row
				if(i%2 == 0)
					contentData += "<tr>";

				contentData += "<td>"
									+"<div class='item_holder'>"
										+"<h3>"+product.getName()+"</h3>"
										
										+"<ul>"
											+"<li class='zoom' id='item'><img src='images/"+product.getImage()+"'></li>"
											+"<li class='btnview'><a href='Menu'>Select<a>"
												
											+"</li>"
											+"<li class='b'>"
												+"<details class='btnview'> <summary>View Details</summary>"
													+"<ul>"
														+"<li>Address : "+product.getManufacturer()+"</li>"
														+"<li>Zipcode: "+product.getCondition()+"</li>"
														
													+"</ul>"
												+"</details>"
											+"</li>"
											+"<li>"
												+"<form action='WriteReview' method='get'>"
												+"<input type='submit' name='writeReviewBtn' class='btnReviewLeft' value='Write Review'>"
												+"<input type='hidden' name='pname' value='"+product.getName()+"'>"
												+"<input type='hidden' name='type' value='Phone'>"
												
												+"</form>"
												+"<form action='ViewReview' method='get'>"
												+"<input type='submit' name='viewReviewBtn' class='btnReviewRight' value='View Review'>"
												+"<input type='hidden' name='pname' value='"+product.getName()+"'>"
												+"</form>"
											+"</li>"
										+"</ul>"
									+"</div>"
								+"</td>";

				if(i%2 != 0)
					contentData += "</tr>";
			}

			contentData += "</table></div></div></div></div>";
		}

		pw.println(contentData);
		utility.printHtml("Footer.html");
	}

}