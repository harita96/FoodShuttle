import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.WebServlet;

@WebServlet("/Home")

public class Home extends HttpServlet
{
	protected void doGet(HttpServletRequest request, HttpServletResponse response) 
		throws ServletException, IOException
	{
		response.setContentType("text/html");
		PrintWriter pw = response.getWriter();
		Utilities utility = new Utilities(request, pw);

		String fileData = utility.ReadHtmlToString("Header.html");

			fileData += "<div id='menu2'><ul float='right'>";
			HttpSession session = request.getSession(true);
			if(session.getAttribute("username") != null)
			{
				String userName = session.getAttribute("username").toString();
				if(userName.equalsIgnoreCase("admin"))
				{
					fileData += "<li><a href='Register'>Register Customer</a></li>"
							+"<li><a href='DeleteCustomer'>Delete Customer</a></li>"
							
							+"<li><a>Hi, ADMIN</a></li>"
							+"<li><a href='Logout'>Logout</a></li>"
							+"</ul></div>";
							//+"<li><a href='ViewCart'>Cart</a></li>";
				}
				else if(userName.equalsIgnoreCase("driver"))
				{
					fileData += "<li><a href='SalesReports'>Orders</a></li>"
							
														
							+"<li><a>Hi, Driver</a></li>"
							+"<li><a href='Logout'>Logout</a></li>"
							+"</ul></div>";
				}
				else
				{
					int count = CartData.getUserCartCount(userName);
				userName = userName.toUpperCase();
				fileData += "<li><a href='ViewOrders'>View Orders</a></li>"
							+"<li><a>Hi, "+ userName +"</a></li>"
							+"<li><a href='Logout'>Logout</a></li>"
							+"<li><a href='ViewCart'><i class='glyphicon glyphicon-shopping-cart'> Cart ("+count+")</i></a></li>"
							+"</ul></div>";
				}
			}
			else
			{
				//"<li class='start selected'><a href=''>View Orders</a></li>"+
				fileData +="<li><a href='Login'>View Orders</a></li>"
	            			+"<li><a href='Register'>Register</a></li>"
	        				+"<li><a href='Login'>Login</a></li>"
	        				//"<li class='end'><a href='#'>Cart</a></li>";
		    				+"<li><a href='Login'><i class='glyphicon glyphicon-shopping-cart'> Cart</i></a></li>"
		    				+"</ul></div>"
	        				+"<img class='header-image' src='images/home7.jpeg' alt='Buildings' />";

			}

		pw.print(fileData);

		//utility.printHtml("Header.html");
		/*
		String contentData = "<div id='content'>"
							+"<div style='width:100%;'>"
							+"<img class='header-image' style='width:100%;' src='images/image.jpg' alt='Buildings' /> </div>"
							+"<div>"
							+"<h2><a href='#'>Welcome to Smart Portables</a></h2>"
							+"<p>Shop your best quality products</p>"
							+"</div></div>";
		pw.println(contentData);
		*/
		//utility.printHtml("LeftNavigationBar.html");
		System.out.println(request);
		utility.printHtml("Content.html");
		utility.printHtml("Footer.html");
	}

}